import pytest
from mylib.function import heynow


@pytest.mark.parametrize("name", ["Paul"])
def test_paul(name):
    heynow(name)


if __name__ == "__main__":

    test_paul()
